<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Role extends Model
{
     public $fillable = [
        'gender',
        'name',
        ];


       public function department()
  {
      return $this->hasMany('App\Employee');
  }
}
