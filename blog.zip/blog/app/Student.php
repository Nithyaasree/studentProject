<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Student extends Model
{
  
    protected $fillable = [
        'name',
        'gender',
        'department',
        'email',
        'password',
        'role',
        'college_name'
    ];

    public function user()
    {
        return $this->belongto('App\Employee');
    }
}
