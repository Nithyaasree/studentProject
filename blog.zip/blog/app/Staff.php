<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Staff extends Model
{
	public $table = "staff";
public $fillable = [
        'name',
        'gender',
        'department',
        'email',
        'password',
        'role',
        'experience',
        'salary'
    ];
    public function department()
  {
      return $this->hasMany('App\Student');
  }
}
