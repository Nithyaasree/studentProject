<?php

namespace App\Http\Controllers;

use App\Employee;
use Illuminate\Http\Request;

class StaffController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $staffs = Employee::all();
        //var_dump($staffs);exit;
       return view('StaffView', compact('staffs','staffs'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return  view('StaffRegister');
            }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'gender' => 'required',
            'department' => 'required',
            'email' => 'required|email',
            'department' => 'required',
            'password' => 'required',
            'role' => 'required',
            'experience' => 'required',
            'salary' => 'required',
        ]);

        $input = $request->all();

        Employee::create($input);
        return redirect()->route('login.Login')->with('sucesslly registered');
          }

    /**
     * Display the specified resource.
     *
     * @param  \App\Staff  $staff
     * @return \Illuminate\Http\Response
     */
    public function show(Employee $id)
    {
         $Employee = Employee::findOrFail($id);
         return view('StaffDetails', compact('staff','staff'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Staff  $staff
     * @return \Illuminate\Http\Response
     */
    public function edit(Employee $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Staff  $staff
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Employee $staff)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Staff  $staff
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
         $staffs = Employee::findOrFail($id);

        $staffs->delete();
        
          return redirect()->route('students.index');
    }
}
