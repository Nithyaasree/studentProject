<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Student;

class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {

        $students = Student::all();
     
        return view('StudentView', compact('students','students'));
        

          }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('StudentRegister');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
          $this->validate($request, [
            'name' => 'required',
            'gender' => 'required',
            'department' => 'required',
            'email' => 'required|email',
            'department' => 'required',
            'password' => 'required',
            'role' => 'required',
        ]);

        $input = $request->all();

        Student::create($input);

        return redirect()->route('login.Login')->with('sucesslly registered');
    }
     


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
         $student = Student::findOrFail($id);
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
          $student = Student::find($id);
      
        return view('students.edit', compact('student','student'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
         $student = Student::findOrFail($id);

        $this->validate($request, [
            'name' => 'required',
            'gender' => 'required',
            'department' => 'required',
            'email' => 'required|email',
            'department' => 'required',
            'password' => 'required',
            'role' => 'required',
        ]);

        $input = $request->all();

        $student->fill($input)->save();

        return redirect()->route('students.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $student = Student::findOrFail($id);

        $student->delete();
        
          return redirect()->route('students.index');
    }
}
