<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Employee;
use App\Student;
use Validator;
use Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;


class LoginController extends Controller
{
  public function index()
    {
         return view('Login');
    }

    public function checklogin(Request $request)
    {
    	

    	// $user_data = array(
     //  'email'  => $request->get('email'),
     //  'password' => $request->get('password'),
     //  'role' => $request->get('role')
     // );
          
        
    	$admin = DB::table('employees')->select('*')->where('email',$request->email)
                                                    ->where('password',$request->password)
                                                    ->where('role',$request->role)
                                                    ->first();
        $students =DB::table('students')->select('*')->where('email',$request->email)
                                                    ->where('password',$request->password)
                                                    ->where('role',$request->role)
                                                    ->first();
              //$password=$admin
              //$role= $admin->role;
                            //

       // $student = Student::findOrFail($students->id);
        // print_r($admin->id);exit;
          // var_dump($request->role==2);exit;
          if($students)
           {
                 $student = Student::findOrFail($students->id);
                 return view('StudentDetails', compact('student','student'));

            }   
          elseif(!$admin)
            {   
                echo "<center><h1>Your Email or Password or role incorrect</h1></center>";
          		return view('login');
             }
          
            else
            { 

                if($request->role==1)
                {
            	    return view('adminlogin');
                }
                elseif($request->role==2) 
                {
                      $staff = Employee::findOrFail($admin->id);
                        // var_dump($staff);exit;
                       return view('StaffDetails', compact('staff','staff'));
                 }  
                else 
                {
                    echo "<center><h1>invalid role</h1></center>";
                      return view('login');
                    
                }
                
            }
        
    }


    public function Adminview()
    {
      $staffs = DB::table('employees as e')
            ->Join('role as r', 'r.id', '=', 'e.role')
            ->select( 'e.id', 'e.name', 'e.gender', 'e.department', 'e.email','r.name as role')
             ->get();

      $student = DB::table('students as s')
            ->Join('role as r', 's.id', '=', 's.role')
            ->select( 's.id', 's.name', 's.gender', 's.department', 's.email','r.name as role')
             ->get();

       $allusers = $staffs->union($student);
      
       //$data = DB::table(DB::raw("({$allusers->toSql()}) AS mg"))->mergeBindings($allusers);
 
        //var_dump($allusers);exit;

        return view('AllView', array ( 'allusers' => $allusers ));
    }


     public function  studentdata()
    {
     //$allusers = 
            //var_dump($allusers);exit;
     //    return view('AllView', array ( 'allusers' => $allusers ));
    }



    
}
