<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Employee extends Model
{
    public $fillable = [
        'name',
        'gender',
        'department',
        'email',
        'password',
        'role',
        'college_name',
        'experience',
        'salary'
    ];

   public function  student()
  {
      return $this->hasMany('App\Role');
  }
}
