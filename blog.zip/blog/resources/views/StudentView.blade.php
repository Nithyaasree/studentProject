@extends('adminlogin')

@section('pageTitle', 'Create A Student')

@section('content')
<body>
  <div class="row">
 <div class="col-md-12">
  <br />
  <h3 align="center">Student Data</h3>
  <br />


  <div align="right">
   
   <br />
   <br />
  </div>
  <table class="table table-bordered table-striped">
   <tr>
    <th>Id</th>
    <th>Name</th>
    <th>Gender</th>
     <th>Department</th>
    <th>Email</th>
    <th>Role</th>
    <th>Delete</th>
   </tr>
@if (is_array($students ?? '' ) || is_object($students ?? '' ))

   @foreach($students ?? ''  as $row)
   <tr>
    <td>{{$row['id']}}</td>
    <td>{{$row['name']}}</td>
    <td>{{$row['gender']}}</td>
    <td>{{$row['department']}}</td>
    <td>{{$row['email']}}</td>
    <td>{{$row['role']}}</td>
    <td>  <form method="post" class="delete_form" action="{{action('StudentController@destroy', $row['id'])}}">
      {{csrf_field()}}
     <input type="hidden" name="_method" value="DELETE" />
      <button type="submit" class="btn btn-danger">Delete</button>
     </form></td>
   </tr>
   @endforeach
   @endif
  </table>
 </div>
</div>
<script>
$(document).ready(function(){
 $('.delete_form').on('submit', function(){
  if(confirm("Are you sure you want to delete it?"))
  {
   return true;
  }
  else
  {
   return false;
  }
 });
});
</script>


</body>

@endsection

