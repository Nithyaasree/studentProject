<!DOCTYPE html>
<html lang="en">
<head>
    @include('elements.meta')
</head>

<body>

@include('elements.header')

<div class="container">
    @yield('content')
</div>



@yield('scripts')
</body>
</html>