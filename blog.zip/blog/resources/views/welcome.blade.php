@extends('master')

@section('pageTitle', 'Home')

<body>

@include('adminpage')
    </body>
  
      @section('content')
@endsection
  
