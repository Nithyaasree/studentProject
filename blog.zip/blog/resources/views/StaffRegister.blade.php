@extends('master')

@section('pageTitle', 'Staff Details')

@section('content')
<body>
  
 <div class="form-name"><center><h1>Staff Register</h1></center></div>

   <div class="card">
    <div class="form-box">
    <form action="{{ action('StaffController@store') }}" method="post">
    {{ csrf_field() }}
   
     <div class="form-group">
      <label for="name" class="col-sm-3"><b>Name</b></label>
      <input type="text" placeholder="Enter Name" name="name"  class="col-sm-8" required>
     </div>

     <div class="form-group">
          <label for="gender" class="col-sm-3"><b>Gender</b></label>
          <input type="radio" name="gender" value="male" required> Male 
          <input type="radio" name="gender" value="female"> Female 
          <input type="radio" name="gender" value="other"> Other
      </div>

    <div class="form-group">
      <label for="dept"class="col-sm-3"><b>Department</b></label>
      <input type="text" placeholder="Department" name="department"  class="col-sm-8" required>
    </div>
   
    <div class="form-group">
      <label for="email"class="col-sm-3"><b>Email</b></label>
      <input type="text" placeholder="Enter Email" name="email"  class="col-sm-8" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required>
    </div>
    
     <div class="form-group">
      <label for="psw" class="col-sm-3"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="password"  class="col-sm-8" required>
    </div>
     
     <div class="form-group">
        <label for="role"  class="col-sm-3"><b>Role<b></label>
        <select id="role" name="role" required>
          <option value="">select</option>
          <option value="2">staff</option>
          <option value="3">student</option>
        </select>
      </div>

       <div class="form-group">
         <label for="experience"  class="col-sm-3"><b>Experience</b></label>
         <input type="text" placeholder="Years Of Experience" name="experience"  class="col-sm-8" required>
       </div>

        <div class="form-group">
          <label for="salary" class="col-sm-3"><b>Salary</b></label>
          <input type="text" placeholder="Salary" name="salary"  class="col-sm-8" required>
     </div>
    <button type="submit" class="btn btn-primary" id="button">Submit</button>
</form>
</div>
</div>
    </body>
<style type="text/css">
  body
    {
            background: #b9cbda;

    }
 .card
    {   
    border-radius: 11px;
    margin-top: 44px;
    padding-top: 40px;
    padding-left: 30px;2
    padding-bottom: 30px;
    margin-right: 19%;
    margin-left: 26%;
    }
    #button
    {
        float: right;
        margin-right: 40px;
      margin-bottom: 20px;

    }
    .form-name
    {
    margin-top: 12px;
    margin-left: 70px;
    }

</style>


@endsection