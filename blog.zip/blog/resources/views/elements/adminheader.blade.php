<nav class="navbar navbar-expand-sm bg-light">

  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="{{route('Staffs.index')}}"> Staff Data</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="{{route('students.index')}}">Student Data</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="{{route('all-data')}}">All Data</a>
    </li>
                  
       </div>
      
      <li class="nav-item">
      <a class="nav-link" href="{{route('login.Login')}}">Logout</a>
    </li>
    <li class="nav-item">
    </li>
  </ul>

</nav>