@extends('adminlogin')

@section('pageTitle', 'All Data')

@section('content')


<body>
  <div class="row">
 <div class="col-md-12">
  <br />
  <h3 align="center">All Data</h3>
  <br />


  <div align="right">
   
   <br />
   <br />
  </div>
  <table class="table table-bordered table-striped">
   <tr>
    <th>Id</th>
    <th>Name</th>
    <th>Gender</th>
     <th>Department</th>
    <th>Email</th>
    <th>Role</th>
   </tr>
@if (is_array($staff ?? '' ) || is_object($staff ?? '' ))

   @foreach($staff ?? ''  as $row)
   <tr>
    <td>{{$row->id }}</td>
    <td>{{$row->name}}</td>
    <td>{{$row->gender }}</td>
    <td>{{$row->department}}</td>
    <td>{{$row->email}}</td>
    <td>{{$row->role}}</td>
    </td>
   </tr>
   @endforeach
   @endif
   @if (is_array($allusers ?? '' ) || is_object($allusers ?? '' ))

   @foreach($allusers ?? ''  as $row)
   <tr>
    <td>{{$row->id }}</td>
    <td>{{$row->name}}</td>
    <td>{{$row->gender }}</td>
    <td>{{$row->department}}</td>
    <td>{{$row->email}}</td>
    <td>{{$row->role}}</td>
    </td>
   </tr>
   
   @endforeach
   @endif
  </table>
 </div>
</div>

</body>

@endsection

