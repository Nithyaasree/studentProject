


<?php $__env->startSection('pageTitle', 'Student Details'); ?>

<?php $__env->startSection('content'); ?>

<body>
  
 <div class="form-name"><center><h1>Student Details</h1></center></div>

   <div class="card">
    <div class="form-box">
    
       <h2><b>Id</b></h2> 
       <h4><?php echo e($student->id); ?> </h4>
        

        <h2><b> Name</b></h2>
       <h4> <?php echo e($student->name); ?> </h4>

        <h2><b>Gender</b></h2>
        <h4><?php echo e($student->gender); ?></h4>

        <h2><b>Email</b></h2>
        <h4><?php echo e($student->email); ?></h4>
        
        <h2><b>Password</b></h2>
        <h4><?php echo e($student->password); ?></h4>
    
     <button type="submit" class="btn btn-danger" id="button">
        <a class="nav-link" href="<?php echo e(route('login.Login')); ?>">Logout</a>
    </button>
   
</div>
</div>
    </body>


    <style type="text/css">
   body
    {
            background: #b9cbda;

    }
 .card
    {   
    border-radius: 11px;
    margin-top: 44px;
    padding-top: 40px;
    padding-left: 30px;2
    padding-bottom: 30px;
    margin-right: 19%;
    margin-left: 26%;
    }
    #button
    {
        float: right;
        margin-right: 40px;
      margin-bottom: 20px;

    }
    .form-name
    {
    margin-top: 12px;
    margin-left: 70px;
    }
  
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\blog\resources\views/StudentDetails.blade.php ENDPATH**/ ?>