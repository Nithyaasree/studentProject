<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('elements.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>


<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>



<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel\blog\resources\views/adminpage.blade.php ENDPATH**/ ?>