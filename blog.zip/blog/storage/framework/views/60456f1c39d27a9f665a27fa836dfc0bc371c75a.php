<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

    </head>
    <body>
        <form action="<?php echo e(action('UserController@store')); ?>" method="post">
    <?php echo e(csrf_field()); ?>


    <label for="name"><b>Name</b></label>
    <input type="text" placeholder="Enter Name" name="name" required>


     
    <label for="gender"><b>Gender</b></label>
    <input type="radio" name="gender" value="male"> Male 
    <input type="radio" name="gender" value="female"> Female 
    <input type="radio" name="gender" value="other"> Other

    <label for="dept"><b>Department</b></label>
    <input type="text" placeholder="Department" name="department" required>

    <label for="email"><b>Email</b></label>
    <input type="text" placeholder="Enter Email" name="email" required>

    <label for="psw"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" required>
 
     <label for="role">Role</label>
      <select id="role" name="role">
        <option value="">select</option>
        <option value="1">staff</option>
        <option value="2">student</option>
      </select>

    <button type="submit" class="btn btn-primary">Submit</button>
</form>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\Laravel\blog\resources\views/register.blade.php ENDPATH**/ ?>