

<?php $__env->startSection('pageTitle', 'Students Index'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="display-6">Students</h1>
   
    <hr/>


    <table class="table">
        <thead>
        <th>id</th>
        <th> Name</th>
        <th>Gender</th>
        <th>Department</th>
        <th>Email</th>
        <th>Role</th>
        <th colspan="3">Actions</th>
        </thead>
          
          <?php $__currentLoopData = $students ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td><?php echo e($student->id); ?></td>
                <td><?php echo e($student->name); ?></td>
                <td><?php echo e($student->gender); ?></td>
                <td><?php echo e($student->department); ?></td>
                <td><?php echo e($student->email); ?></td>
                <td><?php echo e($student->role); ?></td>
                
                <td>
                    <div class="d-flex">
                        <a href="<?php echo e(route('students.show', $student->id)); ?>" class="btn btn-info m-1">Details</a>
                        <a href="<?php echo e(route('students.edit', $student->id)); ?>" class="btn btn-primary m-1">Edit</a>

                        <form action="<?php echo e(route('students.destroy', $student->id)); ?>" method="POST">
                            <input type="hidden" name="_method" value="DELETE">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                            <button class="btn btn-danger m-1">Delete User</button>
                        </form>
                    </div>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\blog\resources\views/students/index.blade.php ENDPATH**/ ?>