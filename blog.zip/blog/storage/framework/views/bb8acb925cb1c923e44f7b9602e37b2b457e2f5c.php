<nav class="navbar navbar-expand-sm bg-light">

  <!-- Links -->
  <ul class="navbar-nav">
    <li class="nav-item">
      <a class="nav-link" href="<?php echo e(route('Staffs.create')); ?>"> Staff Register</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="<?php echo e(route('students.create')); ?>">StudentRegister</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="<?php echo e(route('login.Login')); ?>">Login</a>
    </li>
                  
                </div>
     

    <li class="nav-item">
    </li>
  </ul>

</nav>


<body>
  <style type="text/css">

        {
          background:yellow;
        }
    
  </style>
</body>


 <?php /**PATH C:\xampp\htdocs\Laravel\blog\resources\views/elements/header.blade.php ENDPATH**/ ?>