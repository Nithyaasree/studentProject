

<?php $__env->startSection('pageTitle', 'Login'); ?>

<?php $__env->startSection('content'); ?>
<body>
  <!--  -->
  <div class="form-name"><center><h1>Login Form</h1></center></div>
        <div class="card">
        <div class="form-box">
        <form action="<?php echo e(action('LoginController@checklogin')); ?>" method="post" >
        <?php echo e(csrf_field()); ?>

        	<div class="form-group">
             </td><label for="email" class="col-sm-3"><b>Email</b></label></td>
             </td><input type="text" placeholder="Enter Email" name="email" class="col-sm-8" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required></td>
        </div>

        <div class="form-group">
             <label for="psw" class="col-sm-3"><b>Password</b></label></td>
             <input type="password" placeholder="Enter Password" name="password" class="col-sm-8" required></td>
        </div>
       
       <div class="form-group">
           <label for="role" class="col-sm-3"><b>Role</b></label></td>
           <select id="role" class="col-sm-8" name="role" >
            <option value="">select</option>
            <option value="1">Admin</option>
            <option value="2">staff</option>
            <option value="3">student</option>
          </select></td>
        </div>
        <button type="submit" class="btn btn-primary" id="button" >Login</button>

    </form>
    <style type="text/css">
  body
    {
            background: #b9cbda;

    }
 .card
    {   
    border-radius: 11px;
    margin-top: 44px;
    padding-top: 40px;
    padding-left: 30px;2
    padding-bottom: 30px;
    margin-right: 19%;
    margin-left: 26%;
    }
    #button
    {
        float: right;
        margin-right: 40px;
      margin-bottom: 20px;

    }
    .form-name
    {
    margin-top: 12px;
    margin-left: 70px;
    }

</style>
<script type="text/javascript">


</script>
  <?php $__env->stopSection(); ?>  

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\blog\resources\views/Login.blade.php ENDPATH**/ ?>