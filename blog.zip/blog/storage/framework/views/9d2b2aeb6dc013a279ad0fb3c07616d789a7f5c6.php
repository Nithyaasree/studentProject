<?php $__env->startSection('pageTitle', 'Home'); ?>

<body>

<?php echo $__env->make('adminpage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
  
      <?php $__env->startSection('content'); ?>
<?php $__env->stopSection(); ?>
  

<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\blog\resources\views/welcome.blade.php ENDPATH**/ ?>