<nav class="navbar navbar-expand-lg navbar-light bg-light mb-4">
    <a class="navbar-brand" href="<?php echo e(asset('/')); ?>">MyCrudApp</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown"
            aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(asset('/')); ?>">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown"
                   aria-haspopup="true" aria-expanded="false">
                    Students
                </a>
               
                <a  href="<?php echo $__env->make('students.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>">Create</a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    
                    
                </div>
            </li>
        </ul>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\Laravel\blog\resources\views/college/header.blade.php ENDPATH**/ ?>