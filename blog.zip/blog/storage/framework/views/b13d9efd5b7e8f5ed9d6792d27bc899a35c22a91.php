<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('elements.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>

<?php echo $__env->make('elements.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>



<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel\blog\resources\views/master.blade.php ENDPATH**/ ?>