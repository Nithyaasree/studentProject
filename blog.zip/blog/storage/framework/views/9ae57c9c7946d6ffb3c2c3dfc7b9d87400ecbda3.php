

<?php $__env->startSection('pageTitle', 'Create A Student'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="display-6">Create New Student</h1>

    <hr/>

    <!-- if validation in the controller fails, show the errors -->
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <!-- Open the form with the store function route. -->
    <?php echo e(Form::open(['action' => 'UserController@store'])); ?>


    <!-- Include the CRSF token -->
    <?php echo e(Form::token()); ?>


    
    <!-- build our form inputs -->
    <div class="form-group">
        <?php echo e(Form::label('first_name', 'First Name')); ?>

        <?php echo e(Form::text('first_name', '', ['class' => 'form-control'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('last_name', 'Last Name')); ?>

        <?php echo e(Form::text('last_name', '', ['class' => 'form-control'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('age', 'Age')); ?>

        <?php echo e(Form::number('age', '', ['class' => 'form-control'])); ?>

    </div>

    <div class="form-group">
        <?php echo e(Form::label('email', 'E-Mail Address')); ?>

        <?php echo e(Form::text('email', '', ['class' => 'form-control'])); ?>

    </div>
    <!-- build the submission button -->
    <?php echo e(Form::submit('Create!', ['class' => 'btn btn-primary'])); ?>

    <?php echo e(Form::close()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\blog\resources\views/students/create.blade.php ENDPATH**/ ?>