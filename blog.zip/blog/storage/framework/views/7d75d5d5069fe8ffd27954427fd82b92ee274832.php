

<?php $__env->startSection('pageTitle', 'All Data'); ?>

<?php $__env->startSection('content'); ?>


<body>
  <div class="row">
 <div class="col-md-12">
  <br />
  <h3 align="center">All Data</h3>
  <br />
  <!-- <?php if($message = Session::get('success')): ?>
  <div class="alert alert-success">
   <p><?php echo e($message); ?></p>
  </div>
  <?php endif; ?> -->

  <div align="right">
   
   <br />
   <br />
  </div>
  <table class="table table-bordered table-striped">
   <tr>
    <th>Id</th>
    <th>Name</th>
    <th>Gender</th>
     <th>Department</th>
    <th>Email</th>
    <th>Role</th>
   </tr>
<?php if(is_array($staff ?? '' ) || is_object($staff ?? '' )): ?>

   <?php $__currentLoopData = $staff ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <tr>
    <td><?php echo e($row->id); ?></td>
    <td><?php echo e($row->name); ?></td>
    <td><?php echo e($row->gender); ?></td>
    <td><?php echo e($row->department); ?></td>
    <td><?php echo e($row->email); ?></td>
    <td><?php echo e($row->role); ?></td>
    </td>
   </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php endif; ?>
   <?php if(is_array($allusers ?? '' ) || is_object($allusers ?? '' )): ?>

   <?php $__currentLoopData = $allusers ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <tr>
    <td><?php echo e($row->id); ?></td>
    <td><?php echo e($row->name); ?></td>
    <td><?php echo e($row->gender); ?></td>
    <td><?php echo e($row->department); ?></td>
    <td><?php echo e($row->email); ?></td>
    <td><?php echo e($row->role); ?></td>
    </td>
   </tr>
   
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php endif; ?>
  </table>
 </div>
</div>

</body>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\blog\resources\views/AllView.blade.php ENDPATH**/ ?>