

<?php $__env->startSection('pageTitle', 'Create A Student'); ?>

<?php $__env->startSection('content'); ?>
<body>
  <div class="row">
 <div class="col-md-12">
  <br />
  <h3 align="center">Student Data</h3>
  <br />


  <div align="right">
   
   <br />
   <br />
  </div>
  <table class="table table-bordered table-striped">
   <tr>
    <th>Id</th>
    <th>Name</th>
    <th>Gender</th>
     <th>Department</th>
    <th>Email</th>
    <th>Role</th>
    <th>Delete</th>
   </tr>
<?php if(is_array($students ?? '' ) || is_object($students ?? '' )): ?>

   <?php $__currentLoopData = $students ?? ''; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <tr>
    <td><?php echo e($row['id']); ?></td>
    <td><?php echo e($row['name']); ?></td>
    <td><?php echo e($row['gender']); ?></td>
    <td><?php echo e($row['department']); ?></td>
    <td><?php echo e($row['email']); ?></td>
    <td><?php echo e($row['role']); ?></td>
    <td>  <form method="post" class="delete_form" action="<?php echo e(action('StudentController@destroy', $row['id'])); ?>">
      <?php echo e(csrf_field()); ?>

     <input type="hidden" name="_method" value="DELETE" />
      <button type="submit" class="btn btn-danger">Delete</button>
     </form></td>
   </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <?php endif; ?>
  </table>
 </div>
</div>
<script>
$(document).ready(function(){
 $('.delete_form').on('submit', function(){
  if(confirm("Are you sure you want to delete it?"))
  {
   return true;
  }
  else
  {
   return false;
  }
 });
});
</script>


</body>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\blog\resources\views/StudentView.blade.php ENDPATH**/ ?>